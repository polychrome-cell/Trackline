# TransRail Network Simulator - Standalone HTML / CSS / JS Build

This directory contains the production-ready standalone static files compiled from the React application:

- **`index.html`**: Entry point HTML file with root mounting container and viewport configuration.
- **`style.css`**: Standalone production CSS stylesheet (Tailwind CSS, animations, and tactical dark/light styles).
- **`app.js`**: Standalone JavaScript application bundle (including Google Maps integrations, Recharts, fleet simulation engine, livery designer, and weather economics).
- **`assets/`**: Standard hashed production assets directory referenced by `index.html`.

## How to Run Locally

You can serve this static directory with any web server:

```bash
# Using Python (built into macOS and Linux)
python3 -m http.server 8080 --directory static-html-export

# Or using Node / npx
npx serve static-html-export

# Or using PHP
php -S localhost:8080 -t static-html-export
```

Then open `http://localhost:8080` in any web browser.

## Deploying to Web Hosts

Because this folder contains standard static web assets with relative paths (`./`), you can drag and drop or deploy this directory directly to:
- **GitHub Pages**
- **Vercel** (`vercel deploy static-html-export`)
- **Netlify** (Drag-and-drop the folder in Netlify Drop)
- **Cloudflare Pages**
- **AWS S3 / CloudFront**
- **Firebase Hosting** (`firebase deploy --only hosting`)
- **Nginx / Apache web servers** (copy contents into `/var/www/html/`)
