@echo off
echo Starting Trackline Sim local preview server...
where npx >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  echo Launching via npx serve...
  npx serve . -p 8080
  goto end
)
where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  echo Launching via Python server on http://localhost:8080 ...
  python -m http.server 8080
  goto end
)
echo Python or Node.js not detected.
echo TIP: You can simply double-click "Trackline-Play-Directly.html" to play directly in any browser with zero installation!
pause
:end
