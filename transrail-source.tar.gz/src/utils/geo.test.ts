import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateSegmentDistanceKm, interpolatePolyline } from './geo';

test('calculateSegmentDistanceKm measures realistic distance between cities', () => {
  // Delhi to Mumbai ~1150 km great circle
  const delhi = { lat: 28.6427, lng: 77.2236 };
  const mumbai = { lat: 18.9696, lng: 72.8193 };
  const dist = calculateSegmentDistanceKm(delhi, mumbai);
  assert.ok(dist > 1100 && dist < 1250, `Expected ~1150km, got ${dist}`);
});

test('interpolatePolyline accurately traverses intermediate waypoints', () => {
  const pA = { lat: 0, lng: 0 };
  const pMid = { lat: 10, lng: 0 };
  const pB = { lat: 10, lng: 10 };
  const path = [pA, pMid, pB];

  // At 0% progress -> pA
  const start = interpolatePolyline(path, 0);
  assert.equal(start.lat, 0);
  assert.equal(start.lng, 0);

  // At 50% progress (since both legs are equal length) -> pMid
  const mid = interpolatePolyline(path, 0.5);
  assert.ok(Math.abs(mid.lat - 10) < 0.1);
  assert.ok(Math.abs(mid.lng - 0) < 0.1);

  // At 100% progress -> pB
  const end = interpolatePolyline(path, 1.0);
  assert.equal(end.lat, 10);
  assert.equal(end.lng, 10);
});
